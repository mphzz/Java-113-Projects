
/*
 * Transaction.java
 *
 */
public class Transaction {
  String customerNumber, date, fees;
  int transactionType;
  double amount;

  public Transaction(String customerNumber, int transType, double amount, String fees){
    this.customerNumber = customerNumber;
    this.transactionType = transType;
    this.amount = amount;
    this.fees = fees;
  }
  public void processTran(){
    
  }


 /** Creates a new instance of Transaction */




 
}