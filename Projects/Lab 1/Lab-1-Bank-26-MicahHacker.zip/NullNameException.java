public class NullNameException extends Exception{
  public NullNameException(String str){
    super(str);
  }
}