/*
 * BankApp.java
 */
public class BankApp {
  Bank bank;
  public BankApp(){
    bank = new Bank();
  }
}
// Create a BankApp class

    /** Creates a new instance of BankApp with a new bank */
