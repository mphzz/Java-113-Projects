package edu.miracosta.cs113;
/**
 * PolynomialDriver.java: 
 *
 * @version 1.0
 *
 */


class Main {

    public static void main(String[] args) {
    System.out.println("Hello World");
    //Driver.forName();
    Driver.main(args);
    /*
    **************************************************
    *      YOU MUST USE THIS IN CONSOLE:             *
    *                                                *
    * java -classpath .:target/dependency/* Driver   *
    *                                                *
    *      TO RUN THIS PROGRAM ON REPL.IT            *
    **************************************************
    */
    }
}